__version__ = "0.24.12+bb7e899.1"  # Added by Sailboat








