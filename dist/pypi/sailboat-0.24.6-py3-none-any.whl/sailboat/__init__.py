# Added by Sailboat:
__version__ = "0.24.5-rc.5"
