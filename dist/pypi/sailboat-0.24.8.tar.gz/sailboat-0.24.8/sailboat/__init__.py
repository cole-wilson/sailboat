__version__ = "0.24.8"  # Added by Sailboat



