__version__ = "0.24.12-rc.1"  # Added by Sailboat









