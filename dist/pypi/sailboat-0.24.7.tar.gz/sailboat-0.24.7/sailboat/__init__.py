__version__ = "0.24.7+7d6418d.10"  # Added by Sailboat


