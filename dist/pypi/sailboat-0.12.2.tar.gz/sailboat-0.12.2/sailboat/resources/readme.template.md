# {name}
{short_description}

{description}
## Installation
### With pip:
`pip3 install {short_name}`
{other_install}

## Usage:
Run `{short_name}` in your terminal{other_run}
## Contributors
 - {author}
## Contact
<{email}>